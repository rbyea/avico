$(document).ready(function () {

    $('.select-card').select2({
        placeholder: 'Select an Industry',
        allowClear: false,
        tags: true,
        maximumSelectionLength: 5
    });

    $('.js-example-basic-single').select2({
        minimumResultsForSearch: -1
    });

    $('.js-example-basic').select2({
        minimumResultsForSearch: -1
    });

    $('.toogler-trigger').click(function (e) {
        e.preventDefault();
        $(this).closest('.toogler').find('.toogler__content').stop().slideToggle();
    })

    $('.toogler-triggers').click(function (e) {
        e.preventDefault();
        $(this).closest('.tooglers').find('.tooglers__content').stop().slideToggle();
    })

    $('.toogler-triggers_line').click(function (e) {
        e.preventDefault();
        $(this).closest('.toogler-lines').find('.tooglers__content_line').stop().slideToggle();
        $('.goods__content .slick-slider').slick('setPosition');
    })

    $('.mobile-menu__header_burger').click(function () {
        $(".mobile-menu_close").toggleClass('menu-opened');
    });

    $('.table_reletive').click(function () {
        $(".basket_border_top").toggleClass('border-top_red');
    });


    $('.mobile-menu__middle_link').click(function () {
        $(".mobile_arrow_dark").toggleClass('active');
    });

    $('.active_transparent').click(function () {
        $(this).toggleClass('goods__lines_red');
    });

    $('.index-slider').slick({
        slidesToShow: 1,
        fade: true,
        arrows: false
    })
    $('.hits-slider').slick({
        slidesToShow: 3,
        responsive: [
            {
                breakpoint: 960,
                settings: {
                    slidesToShow: 2
                },
                breakpoint: 590,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    })

    $('.card-slider').slick({
        slidesToShow: 1,
        fade: true,
        asNavFor: '.card-slider_nav',
        arrows: false,
        responsive: [
            {
                breakpoint: 525,
                settings: {
                    arrows: true,
                    prevArrow: "<div class='about_prev'></div>",
                    nextArrow: "<div class='about_next'></div>"
                }
            }
        ]
    })

    $('.card-slider_nav').slick({
        slidesToShow: 3,
        asNavFor: '.card-slider',
        vertical: true,
        prevArrow: "<div class='about_prev'></div>",
        nextArrow: "<div class='about_next'></div>",
    })

    $('.goods-slider').slick({
        slidesToShow: 1,

    })

    $('.about-slider').slick({
        slidesToShow: 3,
        prevArrow: "<div class='about_prev'></div>",
        nextArrow: "<div class='about_next'></div>",
    })

    $('.big-slider-nav__btn').click(function () {
        $(this).closest('.slick-slider').slick('slickGoTo', $(this).index())
    });
    $('.product-slider').slick({
        slidesToShow: 4
    });

    $('.select-cabinet select').select2({
        width: '100%',
        minimumResultsForSearch: Infinity
    });

    $('.custom-select select').select2({
        width: '100%',
        minimumResultsForSearch: Infinity
    });

    $('.select-order select').select2({
        width: '100%',
        minimumResultsForSearch: Infinity
    });
    $('.select-loop select').select2({
        width: '100%',
        minimumResultsForSearch: Infinity
    });
    $('.match-height').matchHeight();
    $('.toggler-header').click(function () {
        $(this).next('.toggler-content').stop().slideToggle();
        $(this).toggleClass('active');
    });
    $('.sphere-slider').slick({
        slidesToShow: 3
    });

    $('.goods-slider_catalog').slick({
        slidesToShow: 4,
        responsive: [
            {
                breakpoint: 1100,
                settings: {
                    slidesToShow: 2
                },
                breakpoint: 590,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    });
    $('.header-window__link').hover(function () {
        $('.header-window__link').removeClass('active');
        $(this).addClass('active');
        $('.header-window__tab').removeClass('active');
        $('.header-window__tab').eq($(this).index()).addClass('active');
    });
    $('.catalog-link-js').click(function (e) {
        e.preventDefault();
        $(this).toggleClass('active');
        $('.header-window').toggleClass('active');
    });
    $('.section-title__text-js').click(function (e) {
        e.preventDefault();
        $('.brands-widget').toggleClass('active');
    });
    $('.header-link-window__link').hover(function () {
        $('.header-link-window__link').removeClass('active');
        $(this).addClass('active');
        $('.header-link-tab').removeClass('active');
        $('.header-link-tab').eq($(this).data('id')).addClass('active');
    });

    $('.brands-trigger').hover(function () {
        $('.header-link-window').addClass('active');
        $(this).addClass('active');
    });
    $('.header-bottom__link:not(.brands-trigger)').hover(function () {
        $('.header-link-window').removeClass('active');
        $('.brands-trigger').removeClass('active');
    });
    $('.header-bottom-wrapper').hover(function () {
        $('.header-link-window').removeClass('active');
        $('.brands-trigger').removeClass('active');
    })

    $(document).mouseup(function (e) { // событие клика по веб-документу
        var div = $(".header-bottom"); // тут указываем ID элемента
        if (!div.is(e.target) // если клик был не по нашему блоку
            && div.has(e.target).length === 0) { // и не по его дочерним элементам
            $('.header-window').removeClass('active');
            $('.catalog-link').removeClass('active');
        }
    });
    $('.chekk').click(
        function () {
            $(this).find(":checkbox").attr("checked", "checked");//выделение всех чекбоксов на кликнутом контейнере, снять выделение через removeAttr("checked")

        });

    $('.tabs__title_list li').not('.active').click(function () {
        var index = $(this).index();
        var content = $('.tabs__content li').eq(index);
        $(this).addClass('active').siblings().removeClass('active');
        $('.tabs__content  li').css('display', 'none').eq(index).css('display', 'block');
    })

    $('.tabs__title_list li:first').addClass('active');
    $('.tabs__content li:first').css('display', 'block');

    $(".minus").click(function () {
        much = +$(this).closest(".quantity").find("input").val();
        result = much - 1;
        if (result < 1) {
            result = 1;
        }
        $(this).closest(".quantity").find("input").val(result);
        updatePrice();
        return true;
    });
    $(".plus").click(function () {
        much = +$(this).closest(".quantity").find("input").val();
        result = much + 1;
        $(this).closest(".quantity").find("input").val(result);
        updatePrice();
        return true;
    });
})