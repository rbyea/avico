$(document).ready(function () {

    $('.toogler-trigger').click(function (e) {
        e.preventDefault();
        $(this).closest('.toogler').find('.toogler__content').slideToggle();
    })

    $('.index-slider').slick({
        slidesToShow: 1,
        fade: true,
        arrows: false
    })
    $('.big-slider-nav__btn').click(function () {
        $(this).closest('.slick-slider').slick('slickGoTo', $(this).index())
    });
    $('.product-slider').slick({
        slidesToShow: 4
    });
    $('.custom-select select').select2({
        width: '100%',
        minimumResultsForSearch: Infinity
    });
    $('.match-height').matchHeight();
    $('.toggler-header').click(function () {
        $(this).next('.toggler-content').stop().slideToggle();
        $(this).toggleClass('active');
    });
    $('.sphere-slider').slick({
        slidesToShow: 3
    });
    $('.header-window__link').hover(function () {
        $('.header-window__link').removeClass('active');
        $(this).addClass('active');
        $('.header-window__tab').removeClass('active');
        $('.header-window__tab').eq($(this).index()).addClass('active');
    });
    $('.catalog-link-js').click(function (e) {
        e.preventDefault();
        $(this).toggleClass('active');
        $('.header-window').toggleClass('active');
    });
    $('.section-title__text-js').click(function (e) {
        e.preventDefault();
        $('.brands-widget').toggleClass('active');
    });
    $('.header-link-window__link').hover(function () {
        $('.header-link-window__link').removeClass('active');
        $(this).addClass('active');
        $('.header-link-tab').removeClass('active');
        $('.header-link-tab').eq($(this).data('id')).addClass('active');
    });

    $('.brands-trigger').hover(function () {
        $('.header-link-window').addClass('active');
        $(this).addClass('active');
    });
    $('.header-bottom__link:not(.brands-trigger)').hover(function () {
        $('.header-link-window').removeClass('active');
        $('.brands-trigger').removeClass('active');
    });
    $('.header-bottom-wrapper').hover(function () {
        $('.header-link-window').removeClass('active');
        $('.brands-trigger').removeClass('active');
    })

    $(document).mouseup(function (e) { // событие клика по веб-документу
        var div = $(".header-bottom"); // тут указываем ID элемента
        if (!div.is(e.target) // если клик был не по нашему блоку
            && div.has(e.target).length === 0) { // и не по его дочерним элементам
            $('.header-window').removeClass('active');
            $('.catalog-link').removeClass('active');
        }
    });
    $('.chekk').click(
        function () {
            $(this).find(":checkbox").attr("checked", "checked");//выделение всех чекбоксов на кликнутом контейнере, снять выделение через removeAttr("checked")

        });
})